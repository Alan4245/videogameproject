﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Esercizio_Videogioco
{
    /// <summary>
    /// schermata di combattimento   nota: il codice scritto qui e nello xaml dovrà essere trasferito verso nel file CombattimentoWindow.cs e CombattimentoWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Combattimento combattimento;

        public MainWindow()
        {
            InitializeComponent();
            try
            {
                //come fai a passare i parametri dei personaggi utilizzati?
                combattimento = new Combattimento(new Personaggio(), new Personaggio(), new Arma(), new Arma());
            }
            catch(Exception ex)
            {
                MessageBox.Show("errore nella creazione del combattimento, err: " + ex.Message);
            }

            
            //collegamento immagini dei personaggi e dello scenario di gioco


            //collegamento progressbar e label per nomi dei personaggi
            lblNomePersonaggio1.Content = combattimento.Personaggio1.Nome;
            lblNomePersonaggio2.Content = combattimento.Personaggio2.Nome;

        }

        //creazione modo di uscire dalla partita
        private void btnTerminaPartita_Click(object sender, RoutedEventArgs e)
        {
            //come riportare la schermata home?
            //questo pulsante dovrà funzionare in qualsiasi momento e se la partità è finita dovrà essere l'unica azione possibile
        }

        private void btnAttacca_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                combattimento.Attacca();
                AggiornamentoGrafica();

                if (combattimento.VerificaFinePartita() == true)
                    FinePartita();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void btnRigenera_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                combattimento.RigeneraSalute();
                AggiornamentoGrafica();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
        //creazione schermata di vittoria con esperienza e statistiche

        public void AggiornamentoGrafica()
        {
            //cambio turno visibile?
            //gestione vitaPersonaggio1-2 con setting dell larghezza in base alla vita utilizzando un calcolo percentuale in base alla vita del personaggio
        }

        public void FinePartita()
        {
            //gestione grafica del fine partita, verranno bloccati i vari bottoni eccetto quello termina partita
            // e verrà prima di tutto aggiornati i vari stati dei personaggi con i metodi assegna esperienza e denaro

            
        }
    }
}
