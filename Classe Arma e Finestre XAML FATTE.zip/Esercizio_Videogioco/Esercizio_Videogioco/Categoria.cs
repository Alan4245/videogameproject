﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Esercizio_Videogioco
{
    public class Categoria
    {
        private string _id;
        private string _nome;

        public Categoria()
        {
           
        }

        public string ID
        {
            get => default;
            set
            {
            }
        }

        public string Nome
        {
            get => default;
            set
            {
            }
        }
    }
}