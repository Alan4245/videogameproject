﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Esercizio_Videogioco
{
    public class Videogioco
    {
        private List<Razza> _razze;
        private List<Personaggio> _personaggi;
        private List<Arma> _armi;
        private List<Categoria> _categorie;

        public Videogioco()
        {
            throw new System.NotImplementedException();
        }

        public List<Razza> Razze
        {
            get => default;
            set
            {
            }
        }

        public List<Personaggio> Personaggi
        {
            get => default;
            set
            {
            }
        }

        public List<Arma> Armi
        {
            get => default;
            set
            {
            }
        }

        public List<Categoria> Categorie
        {
            get => default;
            set
            {
            }
        }

        public void AggiungiArma()
        {
            throw new System.NotImplementedException();
        }

        public void AggiungiCategoria()
        {
            throw new System.NotImplementedException();
        }

        public void AggiungiPersonaggio()
        {
            throw new System.NotImplementedException();
        }

        public void AggiungiRazza()
        {
            throw new System.NotImplementedException();
        }

        public void RimuoviArma()
        {
            throw new System.NotImplementedException();
        }

        public void RimuoviCategoria()
        {
            throw new System.NotImplementedException();
        }

        public void RimuoviPersonaggio()
        {
            throw new System.NotImplementedException();
        }

        public void RimuoviRazza()
        {
            throw new System.NotImplementedException();
        }
    }
}