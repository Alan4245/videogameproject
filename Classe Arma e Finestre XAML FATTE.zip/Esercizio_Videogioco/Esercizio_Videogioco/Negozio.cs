﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Esercizio_Videogioco
{
    public class Negozio
    {

        public void AggiungiArmaPersonaggio()
        {
            throw new System.NotImplementedException();
        }

        public void VendiArmaPersonaggio()
        {
            throw new System.NotImplementedException();
        }

        public void RitornaExp()
        {
            throw new System.NotImplementedException();
        }

        public void RitornaDenaro()
        {
            throw new System.NotImplementedException();
        }

        public void OttieniArmiAbilitatePersonaggio()
        {
            throw new System.NotImplementedException();
        }

        public void OttieniPersonaggio()
        {
            throw new System.NotImplementedException();
        }

        public void OttieniArmiPossedute()
        {
            throw new System.NotImplementedException();
        }
    }
}