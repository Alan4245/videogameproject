﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Esercizio_Videogioco
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Arma a1;
        public MainWindow()
        {
            InitializeComponent();
            Categoria cat = new Categoria();
            a1 = new Arma("arma da taglio", "spada di fuoco", 33,cat, 150, 1000, true);
        }

        private void Btn_GetID_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("ID: " + a1.GetID());
        }

        private void BTN_IsComprata_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("è stata comprata?: " + a1.IsComprata());
        }
    }
}
