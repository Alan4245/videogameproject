﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Esercizio_Videogioco
{
    public class Arma
    {
        private string _nome;
        private double _puntiDanno;
        private string _descrizione;
        private string _id;
        private Categoria _categoria;
        private int _moneteRichieste;
        private int _expRichiesta;

        public Arma()
        {
            throw new System.NotImplementedException();
        }

        public string Descrizione
        {
            get => default;
            set
            {
            }
        }

        public string ID
        {
            get => default;
            set
            {
            }
        }

        public string Nome
        {
            get => default;
            set
            {
            }
        }

        public double PuntiDanno
        {
            get => default;
            set
            {
            }
        }

        public Categoria Categoria
        {
            get => default;
            set
            {
            }
        }

        public int ExpRichiesta
        {
            get => default;
            set
            {
            }
        }

        public int MoneteRichieste
        {
            get => default;
            set
            {
            }
        }

        public bool SeComprata
        {
            get => default;
            set
            {
            }
        }

        public bool IsComprata()
        {
            throw new System.NotImplementedException();
        }
    }
}